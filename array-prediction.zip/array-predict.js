var arr = [8,6,7,5,3,0,9]
for(var i = 0; i < arr.length; i++){    
    console.log(arr[i]);
}
// numbers 8,6,7,5,3,0,9 will be printed { numrat 8,6,7,5,3,0,9 }



